package pour

import (
	"context"
	"embed"
	"encoding/json"
	"errors"
	"fmt"
	"image"
	"image/png"
	"io/fs"
	"net/http"
	"os"
	"path/filepath"
	"sort"
	"sync"
	"time"

	"golang.org/x/sync/errgroup"

	"go.uber.org/multierr"

	"github.com/golang/geo/r3"

	"go.viam.com/rdk/app"
	"go.viam.com/rdk/components/camera"
	toggleswitch "go.viam.com/rdk/components/switch"
	"go.viam.com/rdk/logging"
	"go.viam.com/rdk/motionplan/armplanning"
	"go.viam.com/rdk/referenceframe"
	"go.viam.com/rdk/resource"
	"go.viam.com/rdk/rimage"
	"go.viam.com/rdk/robot"
	"go.viam.com/rdk/services/generic"
	"go.viam.com/rdk/services/motion"
	"go.viam.com/rdk/spatialmath"
	"go.viam.com/rdk/utils"
	viz "go.viam.com/rdk/vision"

	"github.com/erh/vmodutils"
	"github.com/erh/vmodutils/touch"
)

//go:embed vinoweb/dist
var vinowebStaticFS embed.FS

const bottleName = "bottle-top"
const cupTopName = "cup-top"
const gripperToCupCenterHack float64 = -35

const goodPour = "good-pour"
const underPour = "under-pour"
const overPour = "over-pour"
const trainingDataDirName = "training"

const pickQualityDatasetID = "683f8952383a821481d9b5c9"
const pourGlassFindDatasetID = "683d1210c83b3f3823ec70ff"

var VinoCartModel = NamespaceFamily.WithModel("vinocart")
var noObjects = fmt.Errorf("no objects")

const croppedCupDatasetID = "697001c2f47281733615ac57"

func init() {
	resource.RegisterService(generic.API, VinoCartModel, resource.Registration[resource.Resource, *Config]{Constructor: newVinoCart})
}

func newVinoCart(ctx context.Context, deps resource.Dependencies, conf resource.Config, logger logging.Logger) (resource.Resource, error) {
	config, err := resource.NativeConfig[*Config](conf)
	if err != nil {
		return nil, err
	}

	c, err := Pour1ComponentsFromDependencies(config, deps)
	if err != nil {
		return nil, err
	}

	robotClient, err := vmodutils.ConnectToMachineFromEnv(ctx, logger)
	if err != nil {
		return nil, err
	}

	var dataClient *app.DataClient
	var appClient *app.ViamClient
	if config.APIKey != "" && config.APIKeyID != "" {
		appClient, err = app.CreateViamClientWithAPIKey(
			ctx,
			app.Options{},
			config.APIKey,
			config.APIKeyID,
			logger,
		)
	} else {
		appClient, err = app.CreateViamClientFromEnvVars(ctx, nil, logger)
	}

	if err != nil {
		logger.Warnf("can't connect to app: %v", err)
	} else {
		defer appClient.Close()
		dataClient = appClient.DataClient()
	}

	// create directory where images for training data will live
	if err := os.Mkdir(trainingDataDirName, 0755); err != nil {
		if !os.IsExist(err) {
			return nil, fmt.Errorf("failed to create directory: %w", err)
		}
		// Directory already exists, which is fine
	}

	g, err := NewVinoCart(ctx, config, c, robotClient, dataClient, logger)
	if err != nil {
		return nil, err
	}

	logger.Info("the pouring module has been constructed")
	return g, nil
}

func NewVinoCart(ctx context.Context, conf *Config, c *Pour1Components, client robot.Robot, dataClient *app.DataClient, logger logging.Logger) (*VinoCart, error) {
	vc := &VinoCart{
		conf:        conf,
		c:           c,
		robotClient: client,
		dataClient:  dataClient,
		logger:      logger,
	}

	vc.bottleTop = referenceframe.NewLinkInFrame(
		vc.conf.BottleGripper,
		spatialmath.NewPose(r3.Vector{X: vc.conf.BottleHeight - 70, Y: -7, Z: 0}, &spatialmath.OrientationVectorDegrees{OX: 1}),
		bottleName,
		nil,
	)

	vc.cupTop = referenceframe.NewLinkInFrame(
		vc.conf.GripperName,
		spatialmath.NewPose(
			r3.Vector{X: vc.conf.cupGripHeightOffset(), Y: -75, Z: -35},
			&spatialmath.OrientationVectorDegrees{OX: 1},
		),
		cupTopName,
		nil,
	)

	vc.pourExtraFrames = []*referenceframe.LinkInFrame{vc.bottleTop}

	if conf.Loop {
		vc.status = "starting"
		vc.loopWaitGroup.Add(1)
		cancelCtx, cancel := context.WithCancel(context.Background())
		vc.loopCancel = cancel
		go vc.run(cancelCtx)
	} else {
		vc.status = "manual mode"
	}

	realFS, err := fs.Sub(vinowebStaticFS, "vinoweb/dist")
	if err != nil {
		return nil, err
	}

	_, vc.server, err = vmodutils.PrepInModuleServer(realFS, logger.Sublogger("accesslog"), nil)
	if err != nil {
		return nil, err
	}
	go func() {
		vc.server.Addr = ":9999"
		vc.logger.Infof("web listening on %s", vc.server.Addr)
		vc.server.ListenAndServe()
	}()

	vc.pourStep = 0

	vc.useMLModel = conf.UseMLModel
	return vc, nil
}

type VinoCart struct {
	resource.AlwaysRebuild

	name   resource.Name
	logger logging.Logger
	conf   *Config

	robotClient robot.Robot
	dataClient  *app.DataClient

	c *Pour1Components

	bottleTop       *referenceframe.LinkInFrame
	cupTop          *referenceframe.LinkInFrame
	pourExtraFrames []*referenceframe.LinkInFrame
	pourWorldState  *referenceframe.WorldState

	loopCancel    context.CancelFunc
	loopWaitGroup sync.WaitGroup

	statusLock sync.Mutex
	status     string

	server *http.Server

	pourStep int

	imgDirName string

	useMLModel bool

	cancelPour context.CancelFunc
}

func (vc *VinoCart) Name() resource.Name {
	return vc.name
}

func (vc *VinoCart) Close(ctx context.Context) error {
	if vc.loopCancel != nil {
		vc.loopCancel()
		vc.loopWaitGroup.Wait()
	}

	return multierr.Combine(vc.robotClient.Close(ctx), vc.server.Close())
}

func (vc *VinoCart) DoCommand(ctx context.Context, cmd map[string]interface{}) (map[string]interface{}, error) {
	if cmd["status"] == true {
		return map[string]interface{}{"status": vc.getStatus()}, nil
	}

	if cmd["stop"] == true {
		return nil, multierr.Combine(vc.c.Arm.Stop(ctx, nil), vc.c.BottleArm.Stop(ctx, nil))
	}

	if vc.loopCancel != nil {
		return nil, fmt.Errorf("in loop mode, can't do anything but get status")
	}

	defer func() {
		vc.setStatus("manual mode")
	}()

	if cmd["reset"] == true {
		return nil, vc.Reset(ctx)
	}

	if cmd["touch"] == true {
		return nil, vc.Touch(ctx)
	}

	if cmd["pour-prep"] == true {
		return nil, vc.PourPrep(ctx)
	}

	if cmd["pour"] == true {
		return nil, vc.Pour(ctx)
	}

	if cmd["put-back"] == true {
		return nil, vc.PutBack(ctx)
	}

	if cmd["demo"] == true {
		return nil, vc.FullDemo(ctx)
	}
	if cmd["test_position"] != nil {
		positionCmd, ok := cmd["test_position"].(map[string]interface{})
		if !ok {
			return nil, fmt.Errorf("test_position must be a map")
		}

		stage, ok := positionCmd["stage"].(string)
		if !ok {
			return nil, fmt.Errorf("test_position.stage must be a string")
		}

		step, ok := positionCmd["step"].(string)
		if !ok {
			return nil, fmt.Errorf("test_position.step must be a string")
		}

		return nil, vc.doAll(ctx, stage, step, 50)
	}

	if cmd["over-pour"] == true {
		return nil, vc.labelPour(ctx, overPour)
	}

	if cmd["under-pour"] == true {
		return nil, vc.labelPour(ctx, underPour)
	}

	if cmd["good-pour"] == true {
		return nil, vc.labelPour(ctx, goodPour)
	}

	if cmd["stop-pour"] == true {
		return nil, vc.CancelPour()
	}
	return nil, fmt.Errorf("need a command")
}

func (vc *VinoCart) run(ctx context.Context) {
	defer vc.loopWaitGroup.Done()
	for ctx.Err() == nil {
		vc.setStatus("standby")
		err := vc.WaitForCupAndGo(ctx)
		if err != nil {
			vc.logger.Errorf("go error in run: %v", err)
		}
	}
}

func (vc *VinoCart) getStatus() string {
	vc.statusLock.Lock()
	defer vc.statusLock.Unlock()
	return vc.status
}

func (vc *VinoCart) setStatus(s string) {
	vc.logger.Infof("setStatus: %v", s)
	vc.statusLock.Lock()
	defer vc.statusLock.Unlock()
	vc.status = s
}

func (vc *VinoCart) WaitForCupAndGo(ctx context.Context) error {
	for {
		err := vc.FullDemo(ctx)
		if err == nil {
			break
		}
		if err != noObjects {
			return err
		}
		vc.logger.Infof("got %v, looping", err)
	}

	vc.setStatus("waiting")

	// need to wait till the area is clear
	vc.logger.Infof("waiting for area to be clear")

	for {
		objects, err := vc.FindCups(ctx)
		if err != nil {
			return err
		}

		vc.logger.Infof("num objects while waiting: %v", len(objects))
		for _, o := range objects {
			vc.logger.Infof("\t objects: %v", o)
		}
		if len(objects) == 0 {
			return nil
		}
	}
}

func (vc *VinoCart) FullDemo(ctx context.Context) error {
	err := vc.Touch(ctx)
	if err != nil {
		return err
	}
	err = vc.PourPrep(ctx)
	if err != nil {
		return err
	}
	err = vc.Pour(ctx)
	if err != nil {
		return err
	}
	return vc.PutBack(ctx)
}

func (vc *VinoCart) Reset(ctx context.Context) error {
	defer func() {
		vc.pourStep = 0
		if err := vc.cleanupImages(); err != nil {
			vc.logger.Errorf("failed to cleanup images: %v\n", err)
		}
	}()

	g := errgroup.Group{}

	cupHoldingStatus, err := vc.c.Gripper.IsHoldingSomething(ctx, nil)
	if err != nil {
		return err
	}
	bottleHoldingStatus, err := vc.c.BottleGripper.IsHoldingSomething(ctx, nil)
	if err != nil {
		return err
	}
	g.Go(func() error {
		var err error
		if cupHoldingStatus.IsHoldingSomething {
			err = vc.doAll(ctx, "reset", "left-holding-pre", 50)
			if err != nil {
				return err
			}

			err = vc.moveToCurrentXYAtCupHeight(ctx)
			if err != nil {
				return err
			}

			err = vc.c.Gripper.Open(ctx, nil)
			if err != nil {
				return err
			}

			time.Sleep(time.Millisecond * 500)
			err = vc.doAll(ctx, "reset", "left-holding-post", 50)
			if err != nil {
				return err
			}
		}
		return nil
	})

	g.Go(func() error {
		var err error
		if bottleHoldingStatus.IsHoldingSomething {
			err = vc.doAll(ctx, "reset", "right-holding-pre", 50)
			if err != nil {
				return err
			}

			err = vc.c.BottleGripper.Open(ctx, nil)
			if err != nil {
				return err
			}

			time.Sleep(time.Millisecond * 500)

			err = vc.doAll(ctx, "reset", "right-holding-post", 50)
			if err != nil {
				return err
			}

		}
		return nil
	})

	err2 := g.Wait()
	if err2 != nil {
		return err2
	}
	err3 := vc.doAll(ctx, "touch", "prep", 100)
	if err3 != nil {
		return err3
	}

	// Lastly, open both grippers in the case that they are fully closed (which is different than holding something)
	g.Go(func() error {
		return vc.c.Gripper.Open(ctx, nil)
	})

	g.Go(func() error {
		return vc.c.BottleGripper.Open(ctx, nil)
	})

	err4 := g.Wait()
	if err4 != nil {
		return err4
	}

	vc.logger.Info("finished resetting")
	return nil
}

func (vc *VinoCart) GrabCup(ctx context.Context) error {
	got, err := vc.c.Gripper.Grab(ctx, nil)
	if err != nil {
		return err
	}

	if !got {
		return fmt.Errorf("didn't get cup")
	}

	return vc.checkPickQuality(ctx)
}

func (vc *VinoCart) checkPickQuality(ctx context.Context) error {

	if vc.c.PickQualityService == nil {
		return nil
	}

	imgs, _, err := vc.c.Cam.Images(ctx, nil, nil)
	if err != nil {
		return err
	}

	if imgs[0].SourceName != "" && imgs[0].SourceName != "color" {
		return fmt.Errorf("bad image name [%v]", imgs[0].SourceName)
	}

	i, err := imgs[0].Image(ctx)
	if err != nil {
		return err
	}

	prepped, err := prepPickImage(i)
	if err != nil {
		return err
	}

	if vc.dataClient != nil {
		vc.logger.Infof("uploading image to dataset for cup pick quality")
		err := saveImageToDataset(ctx, vc.c.Cam.Name(), prepped, vc.dataClient, pickQualityDatasetID, nil)
		if err != nil {
			vc.logger.Warnf("can't saveCupImage: %v", err)
		}
	}

	cs, err := vc.c.PickQualityService.Classifications(ctx, prepped, 1, nil)
	if err != nil {
		return err
	}

	vc.logger.Infof("quality: %v", cs)

	if len(cs) != 1 {
		return fmt.Errorf("why is quality array wrong: %v", cs)
	}

	if cs[0].Label() == "good" {
		return nil
	}

	// bad pick, move

	err = vc.doAll(ctx, "touch", "bad-pick-a", 50)
	if err != nil {
		return err
	}

	err = vc.c.Gripper.Open(ctx, nil)
	if err != nil {
		return err
	}

	err = vc.doAll(ctx, "touch", "bad-pick-b", 50)
	if err != nil {
		return err
	}

	return fmt.Errorf("bad pick %v", cs[0])
}

func saveImageToDatasetFromCamera(ctx context.Context, cam camera.Camera, dataClient *app.DataClient, dataSetId string) error {
	imgs, _, err := cam.Images(ctx, nil, nil)
	if err != nil {
		return err
	}
	i, err := imgs[0].Image(ctx)
	if err != nil {
		return err
	}
	return saveImageToDataset(ctx, cam.Name(), i, dataClient, dataSetId, nil)
}

func findFiles(ctx context.Context, root string) ([]string, error) {
	var files []string
	if err := filepath.WalkDir(root, func(path string, d fs.DirEntry, err error) error {
		if err != nil {
			return err
		}
		if d.IsDir() {
			return nil
		}
		files = append(files, path)
		return nil
	}); err != nil {
		return nil, err
	}
	sort.Strings(files)
	return files, nil
}

func (vc *VinoCart) cleanupImages() error {
	if vc.imgDirName == "" {
		return nil
	}
	if err := os.RemoveAll(vc.imgDirName); err != nil {
		return err
	}
	vc.imgDirName = ""
	return nil
}

func uploadTaggedImages(ctx context.Context, componentName string, folderPath string, dataClient *app.DataClient, dataSetId string, label string, logger logging.Logger) error {
	pid := os.Getenv("VIAM_MACHINE_PART_ID")
	if pid == "" {
		return fmt.Errorf("VIAM_MACHINE_PART_ID not defined")
	}
	pourTime := filepath.Base(folderPath)
	notFullOpts := &app.FileUploadOptions{
		ComponentName: &componentName,
		Tags:          []string{"not-full", pourTime},
		DatasetIDs:    []string{dataSetId},
	}

	fullOpts := &app.FileUploadOptions{
		ComponentName: &componentName,
		Tags:          []string{"full", pourTime},
		DatasetIDs:    []string{dataSetId},
	}

	files, err := findFiles(ctx, folderPath)
	if err != nil {
		return err
	}

	logger.Infof("found %d files in folder %s", len(files), folderPath)

	numFiles := len(files)

	// Our logic uploads a max of 2 not-full images per pour
	// This is due to how during a pour, the vast majority of images are
	// in a not-full state. Once the full state is hit, we stop pouring.
	// If we were to upload all images, then they'd be heavily skewed towards not-full
	switch label {

	// tag last 2 images as not full
	case underPour:
		// guard against index out of bounds
		endBoundary := max(0, numFiles-2)

		for _, filepath := range files[endBoundary:] {
			if _, err := dataClient.FileUploadFromPath(ctx, pid, filepath, notFullOpts); err != nil {
				return err
			}
		}

	// tag the last 2 images before the stopping point as not-full
	case goodPour:
		// guard against index out of bounds
		threeFromEndBoundary := max(0, numFiles-3)
		oneFromEndBoundary := max(0, numFiles-1)

		for _, path := range files[threeFromEndBoundary:oneFromEndBoundary] {
			if _, err := dataClient.FileUploadFromPath(ctx, pid, path, notFullOpts); err != nil {
				return err
			}
		}
		// tag the last image as full
		if numFiles > 0 {
			if _, err := dataClient.FileUploadFromPath(ctx, pid, files[numFiles-1], fullOpts); err != nil {
				return err
			}
		}

	// We assume that the last 3 images are full, this is an approximation of the amount of over-pouring
	// We also label the 2 images before the full/over-pour section as not-full
	case overPour:
		// guard against index out of bounds
		fiveFromEndBoundary := max(0, numFiles-5)
		threeFromEndBoundary := max(0, numFiles-3)

		for _, path := range files[fiveFromEndBoundary:threeFromEndBoundary] {
			if _, err := dataClient.FileUploadFromPath(ctx, pid, path, notFullOpts); err != nil {
				return err
			}
		}

		for _, path := range files[threeFromEndBoundary:] {
			if _, err := dataClient.FileUploadFromPath(ctx, pid, path, fullOpts); err != nil {
				return err
			}
		}
	default:
		return errors.New("not valid label")
	}
	return nil
}

func saveImageToDataset(ctx context.Context, component resource.Name, img image.Image, dataClient *app.DataClient, dataSetId string, tags []string) error {
	pid := os.Getenv("VIAM_MACHINE_PART_ID")
	if pid == "" {
		return fmt.Errorf("VIAM_MACHINE_PART_ID not defined")
	}

	data, err := encodePNG(img)
	if err != nil {
		return err
	}

	ct := component.API.String()
	cn := component.ShortName()
	pngString := "png"

	opts := app.FileUploadOptions{
		ComponentType: &ct,
		ComponentName: &cn,
		FileExtension: &pngString,
		Tags:          tags,
	}

	id, err := dataClient.FileUploadFromBytes(ctx, pid, data, &opts)
	if err != nil {
		return err
	}

	err = dataClient.AddBinaryDataToDatasetByIDs(ctx, []string{id}, dataSetId)
	if err != nil {
		return err
	}

	return nil
}

func (vc *VinoCart) Touch(ctx context.Context) error {
	vc.setStatus("looking")

	err := vc.Reset(ctx)
	if err != nil {
		return err
	}

	start := time.Now()
	objects, err := vc.FindCups(ctx)
	if err != nil {
		return err
	}

	vc.logger.Infof("num objects: %v in %v", len(objects), time.Since(start))
	for _, o := range objects {
		vc.logger.Infof("\t objects: %v", o)
	}

	if len(objects) == 0 {
		return noObjects
	}

	if len(objects) > 1 {
		return fmt.Errorf("too many objects %d", len(objects))
	}

	vc.setStatus("picking")

	obj := objects[0]

	// -- setup world frame

	obstacles := []*referenceframe.GeometriesInFrame{}
	// Set a label on the cup geometry to avoid "unnamedWorldStateGeometry" collisions
	obj.Geometry.SetLabel("cup")
	obstacles = append(obstacles, referenceframe.NewGeometriesInFrame("world", []spatialmath.Geometry{obj.Geometry}))
	vc.logger.Infof("add cup as obstacle %v", obj.Geometry)

	worldState, err := referenceframe.NewWorldState(obstacles, nil)
	if err != nil {
		return err
	}

	// -- approach

	var o *spatialmath.OrientationVectorDegrees

	choices := []*spatialmath.OrientationVectorDegrees{
		{OX: 1, Theta: 180},
		{OY: 1, Theta: 180},
		{OX: .5, OY: 1, Theta: 180},
		{OX: 1, OY: 1, Theta: 180},
		{OX: 1, OY: -1, Theta: 180},
		{OY: -1, Theta: 180},
		{OX: -.5, OY: -1, Theta: 180},
	}

	approaches := []*referenceframe.PoseInFrame{}

	for _, tryO := range choices {
		goToPose := vc.getApproachPoint(obj, 100, tryO)
		approaches = append(approaches, goToPose)
		vc.logger.Infof("trying to move to %v", goToPose.Pose())

		_, err2 := vc.c.Motion.Move(
			ctx,
			motion.MoveReq{
				ComponentName: vc.c.Gripper.Name().ShortName(),
				Destination:   goToPose,
				WorldState:    worldState,
				Extra:         planTagExtra("touch-approach"),
			},
		)

		if err2 != nil {
			vc.logger.Debugf("error: %v", err2)
		}

		if err2 == nil {
			err = nil
			o = tryO
			break
		} else if err == nil {
			err = err2
		}

	}

	if vc.conf.Handoff && err != nil {

		err2 := vc.handoffCupBottleToCupArm(ctx, worldState, approaches, choices, obj)
		if err2 == nil {
			return nil
		}

		return multierr.Combine(err, err2)
	}

	if err != nil {
		return err
	}

	// ---- go to pick up
	err = SetXarmSpeed(ctx, vc.c.Arm, 25, 25)
	if err != nil {
		return err
	}

	goToPose := vc.getApproachPoint(obj, gripperToCupCenterHack, o)
	vc.logger.Infof("going to move to %v", goToPose)

	err = moveWithLinearConstraint(ctx, vc.c.Motion, vc.c.Gripper.Name(), goToPose, "touch-pickup")
	if err != nil {
		return err
	}

	return vc.GrabCup(ctx)
}

func (vc *VinoCart) handoffCupBottleToCupArm(ctx context.Context, worldState *referenceframe.WorldState, approaches []*referenceframe.PoseInFrame, choices []*spatialmath.OrientationVectorDegrees, obj *viz.Object) error {
	for idx, goToPose := range approaches {
		vc.logger.Infof("trying to move (2) to %v", goToPose.Pose())

		_, err := vc.c.Motion.Move(
			ctx,
			motion.MoveReq{
				ComponentName: vc.c.BottleGripper.Name().ShortName(),
				Destination:   goToPose,
				WorldState:    worldState,
				Extra:         planTagExtra("handoff-approach"),
			},
		)
		if err != nil {
			vc.logger.Infof("error (2): %v", err)
			continue
		}

		// we found a path!

		goToPose = vc.getApproachPoint(obj, gripperToCupCenterHack, choices[idx])
		vc.logger.Infof("going to move (2) to %v", goToPose)

		err = moveWithLinearConstraint(ctx, vc.c.Motion, vc.c.BottleGripper.Name(), goToPose, "handoff-pickup")
		if err != nil {
			return err
		}

		got, err := vc.c.BottleGripper.Grab(ctx, nil)
		if err != nil {
			return err
		}
		if !got {
			return fmt.Errorf("didn't grab cup from bottlegripper")
		}

		// move to known spot
		goToPose = vc.getApproachPoint(obj, 150, choices[idx])
		err = moveWithLinearConstraint(ctx, vc.c.Motion, vc.c.BottleGripper.Name(), goToPose, "handoff-lift")
		if err != nil {
			return err
		}

		// release
		err = vc.c.BottleGripper.Open(ctx, nil)
		if err != nil {
			return err
		}

		// backup
		goToPose = vc.getApproachPoint(obj, 250, choices[idx])
		err = moveWithLinearConstraint(ctx, vc.c.Motion, vc.c.BottleGripper.Name(), goToPose, "handoff-backup")
		if err != nil {
			return err
		}

		return vc.Touch(ctx)
	}
	return fmt.Errorf("no path for handoff")
}

func (vc *VinoCart) getApproachPoint(obj *viz.Object, deltaLinear float64, o *spatialmath.OrientationVectorDegrees) *referenceframe.PoseInFrame {
	md := obj.MetaData()
	c := md.Center()

	p := touch.GetApproachPoint(c, deltaLinear, o)
	p.Z = vc.conf.CupHeight - vc.conf.cupGripHeightOffset()

	return referenceframe.NewPoseInFrame(
		"world",
		spatialmath.NewPose(p, o),
	)
}

func (vc *VinoCart) getPositions(stage, step string) ([][]toggleswitch.Switch, error) {
	steps, ok := vc.c.Positions[stage]
	if !ok {
		return nil, fmt.Errorf("no stage %s", stage)
	}
	positions, ok := steps[step]
	if !ok {
		return nil, fmt.Errorf("no step [%s] in stage [%s]", step, stage)
	}
	return positions, nil
}

func (vc *VinoCart) DoAll(ctx context.Context, stage, step string) error {
	return vc.doAll(ctx, stage, step, 50)
}

func (vc *VinoCart) doAll(ctx context.Context, stage, step string, speedAndAccelBothArm float64) error {
	err := SetXarmSpeed(ctx, vc.c.Arm, speedAndAccelBothArm, speedAndAccelBothArm)
	if err != nil {
		return err
	}

	err = SetXarmSpeed(ctx, vc.c.BottleArm, speedAndAccelBothArm, speedAndAccelBothArm)
	if err != nil {
		return err
	}

	positions, err := vc.getPositions(stage, step)
	if err != nil {
		return err
	}

	for _, xxx := range positions {
		err := vc.goTo(ctx, xxx...)
		if err != nil {
			return err
		}
	}
	return nil
}

func (vc *VinoCart) PourPrepGrab(ctx context.Context) error {
	positions, err := vc.c.BottleArm.JointPositions(ctx, nil)
	if err != nil {
		return err
	}

	orig := positions[0]

	vc.logger.Infof("pourPrepGrab orig: %v", orig)
	positions[0] -= utils.DegToRad(2)
	vc.logger.Infof("pourPrepGrab hack: %v", positions[0])

	err = vc.c.BottleArm.MoveToJointPositions(ctx, positions, nil)
	if err != nil {
		return err
	}

	time.Sleep(50 * time.Millisecond)

	gotTheBottle, err := vc.c.BottleGripper.Grab(ctx, nil)
	if err != nil {
		return err
	}

	time.Sleep(50 * time.Millisecond)

	positions[0] = orig
	positions[5] -= .3 // tilt bottle to increase friction

	err = vc.c.BottleArm.MoveToJointPositions(ctx, positions, nil)
	if err != nil {
		return err
	}

	if !gotTheBottle {
		return fmt.Errorf("didn't grab the bottle")
	}

	return nil
}

func (vc *VinoCart) PourPrep(ctx context.Context) error {
	vc.setStatus("prepping")

	holdingStatus, err := vc.c.Gripper.IsHoldingSomething(ctx, nil)
	if err != nil {
		return err
	}
	if !holdingStatus.IsHoldingSomething {
		return fmt.Errorf("gripper %v is not holding cup", vc.c.Gripper.Name())
	}

	err = vc.doAll(ctx, "pour_prep", "prep-grab", 80)
	if err != nil {
		return err
	}

	err = vc.doAll(ctx, "pour_prep", "right-grab", 80)
	if err != nil {
		return err
	}

	err = vc.PourPrepGrab(ctx)
	if err != nil {
		return err
	}

	err = vc.doAll(ctx, "pour_prep", "post-grab", 50)
	if err != nil {
		return err
	}
	return nil
}

func (vc *VinoCart) goTo(ctx context.Context, poss ...toggleswitch.Switch) error {
	if len(poss) == 0 {
		return nil
	}

	if len(poss) == 1 {
		return poss[0].SetPosition(ctx, 2, nil)
	}

	var errorLock sync.Mutex
	errors := []error{}

	wg := sync.WaitGroup{}

	for _, p := range poss {
		wg.Add(1)
		go func(pp toggleswitch.Switch) {
			defer wg.Done()
			err := pp.SetPosition(ctx, 2, nil)
			if err != nil {
				errorLock.Lock()
				errors = append(errors, err)
				errorLock.Unlock()
			}
		}(p)

	}

	wg.Wait()

	return multierr.Combine(errors...)
}

func (vc *VinoCart) moveToCurrentXYAtCupHeight(ctx context.Context) error {
	cur, err := vc.c.Motion.GetPose(ctx, vc.conf.GripperName, "world", vc.pourExtraFrames, nil)
	if err != nil {
		return err
	}

	cur = referenceframe.NewPoseInFrame(
		cur.Parent(),
		spatialmath.NewPose(r3.Vector{
			X: cur.Pose().Point().X,
			Y: cur.Pose().Point().Y,
			Z: vc.conf.CupHeight - vc.conf.cupGripHeightOffset(),
		}, cur.Pose().Orientation()))

	_, err = vc.c.Motion.Move(
		ctx,
		motion.MoveReq{
			ComponentName: vc.conf.GripperName,
			Destination:   cur,
			Extra:         planTagExtra("descend-cup-height"),
		},
	)
	return err
}

func (vc *VinoCart) getPourDetails(ctx context.Context, img image.Image) (string, float64, error) {
	if vc.c.DataFullnessService == nil {
		return "", 0, nil
	}
	cs, err := vc.c.DataFullnessService.Classifications(ctx, img, 1, nil)
	if err != nil {
		return "", 0, err
	}
	if len(cs) == 0 {
		return "", 0, nil
	}
	return cs[0].Label(), cs[0].Score(), nil
}

func (vc *VinoCart) PourGlassFindCroppedRect(ctx context.Context) (*image.Rectangle, error) {
	detections, err := vc.c.PourGlassFindService.DetectionsFromCamera(ctx, "", nil)
	if err != nil {
		return nil, err
	}

	if len(detections) == 0 {
		return nil, fmt.Errorf("did not find glass to monitor pour")
	}

	return detections[0].BoundingBox(), nil
}

func (vc *VinoCart) PourGlassFindCroppedImage(ctx context.Context, r *image.Rectangle) (image.Image, error) {

	imgs, _, err := vc.c.GlassPourCam.Images(ctx, nil, nil)
	if err != nil {
		return nil, err
	}

	img, err := imgs[0].Image(ctx)
	if err != nil {
		return nil, err
	}

	lazy, ok := img.(*rimage.LazyEncodedImage)
	if ok {
		img, err = lazy.DecodedImage()
		if err != nil {
			return nil, err
		}
	}

	return img.(subImager).SubImage(*r), nil
}

type subImager interface {
	SubImage(r image.Rectangle) image.Image
}

func (vc *VinoCart) GetGlassPourCamImage(ctx context.Context, box *image.Rectangle, loopNumber int) (image.Image, string, error) {
	img, err := vc.PourGlassFindCroppedImage(ctx, box)
	if err != nil {
		return nil, "", err
	}

	fn := ""
	if loopNumber >= 0 {
		_, err = saveImage(img, vc.imgDirName, loopNumber, vc.logger)
		if err != nil {
			return nil, "", err
		}
	}

	return img, fn, nil
}

func (vc *VinoCart) Pour(ctx context.Context) error {
	vc.setStatus("pouring")

	// set up gripper + arms
	isHoldingCup, err := vc.c.Gripper.IsHoldingSomething(ctx, nil)
	if err != nil {
		return err
	}
	if !isHoldingCup.IsHoldingSomething {
		return fmt.Errorf("gripper %v is not holding a cup", vc.c.Gripper.Name())
	}

	isHoldingBottle, err := vc.c.BottleGripper.IsHoldingSomething(ctx, nil)
	if err != nil {
		return err
	}
	if !isHoldingBottle.IsHoldingSomething {
		return fmt.Errorf("bottle gripper %v is not holding bottle", vc.c.BottleGripper.Name())
	}

	err = SetXarmSpeed(ctx, vc.c.Arm, 50, 50)
	if err != nil {
		return err
	}
	err = SetXarmSpeed(ctx, vc.c.BottleArm, 50, 50)
	if err != nil {
		return err
	}
	positions, err := vc.getPositions("pour", "prep")
	if err != nil {
		return err
	}
	err = vc.goTo(ctx, positions[0]...)
	if err != nil {
		return err
	}

	// Dynamic alignment: move bottle-top to cup-top + gap (replaces arm-pour-right-pos0)
	// Uses armplanning.PlanMotion (right arm only) to avoid gripper-vs-gripper collision checks
	cupTransforms := []*referenceframe.LinkInFrame{vc.cupTop}
	cupTarget, err := vc.c.Motion.GetPose(ctx, cupTopName, "world", cupTransforms, nil)
	if err != nil {
		return fmt.Errorf("failed to get cup-top pose: %w", err)
	}
	bottleTopNow, err := vc.c.Motion.GetPose(ctx, bottleName, "world", vc.pourExtraFrames, nil)
	if err != nil {
		return fmt.Errorf("failed to get bottle-top pose: %w", err)
	}
	gapOffset := r3.Vector{Z: 50}
	alignTarget := referenceframe.NewPoseInFrame("world",
		spatialmath.NewPose(cupTarget.Pose().Point().Add(gapOffset), bottleTopNow.Pose().Orientation()),
	)
	vc.logger.Infof("aligning bottle-top to: %v", alignTarget.Pose())

	alignFs, err := touch.FrameSystemWithSomeParts(ctx, vc.c.Rfs, []string{vc.conf.BottleArm, vc.conf.BottleGripper}, vc.pourExtraFrames)
	if err != nil {
		return fmt.Errorf("failed to build align frame system: %w", err)
	}
	alignJoints, err := vc.c.BottleArm.JointPositions(ctx, nil)
	if err != nil {
		return err
	}
	alignReq := &armplanning.PlanRequest{
		FrameSystem: alignFs,
		Goals: []*armplanning.PlanState{
			armplanning.NewPlanState(referenceframe.FrameSystemPoses{bottleName: alignTarget}, nil),
		},
		StartState: armplanning.NewPlanState(nil, referenceframe.FrameSystemInputs{
			vc.conf.BottleArm: alignJoints,
		}),
	}
	alignPlan, _, err := armplanning.PlanMotion(ctx, vc.logger, alignReq)
	if err != nil {
		return fmt.Errorf("failed to plan bottle alignment: %w", err)
	}
	for i, step := range alignPlan.Trajectory() {
		vc.logger.Infof("[bottle-to-cup-align] plan step %d: %v", i, step[vc.conf.BottleArm])
	}
	if len(alignPlan.Trajectory()) != 2 {
		return fmt.Errorf("[bottle-to-cup-align] unexpected trajectory length (%d)", len(alignPlan.Trajectory()))
	}
	alignGoalJoints := alignPlan.Trajectory()[1][vc.conf.BottleArm]
	alignL2 := referenceframe.InputsL2Distance(alignJoints, alignGoalJoints)
	vc.logger.Infof("[bottle-to-cup-align] InputsL2Distance: %v", alignL2)
	if alignL2 > 0.15 {
		fn := "/tmp/align-plan-bad.json"
		data, err := json.MarshalIndent(alignReq, "", "  ")
		if err != nil {
			return err
		}
		if err := os.WriteFile(fn, data, 0o600); err != nil {
			return err
		}
		return fmt.Errorf("[bottle-to-cup-align] pos too far %v, written to: %s", alignL2, fn)
	}
	vc.logger.Infof("[bottle-to-cup-align] moving bottle arm to align with cup target")
	err = vc.c.BottleArm.MoveToJointPositions(ctx, alignGoalJoints, nil)
	if err != nil {
		return fmt.Errorf("failed to align bottle to cup: %w", err)
	}

	pp, err := vc.SetupPourPositions(ctx)
	if err != nil {
		return err
	}
	time.Sleep(500 * time.Millisecond)

	// oldModel vars
	var pd *pourDetector
	markedDifferent := false

	totalTime := 15 * time.Second

	pourContext, cancelPour := context.WithCancel(ctx)
	vc.cancelPour = cancelPour
	wg := sync.WaitGroup{}
	wg.Add(1)

	if vc.dataClient != nil && vc.c.GlassPourCam != nil {
		vc.logger.Infof("uploading image to dataset for cup finding")
		wg.Add(1)
		go func() {
			defer wg.Done()
			err := saveImageToDatasetFromCamera(context.Background(), vc.c.GlassPourCam, vc.dataClient, pourGlassFindDatasetID)
			if err != nil {
				vc.logger.Errorf("error saving cup cam to data set: %v", err)
			}
		}()
	}

	box, err := vc.PourGlassFindCroppedRect(ctx)
	if err != nil {
		return err
	}
	vc.logger.Infof("got box for crop %v", box)

	go func() {
		defer wg.Done()
		err := vc.doPourMotion(ctx, pourContext, pp)
		if err != nil {
			vc.logger.Infof("error pouring: %v", err)
		}
	}()

	defer func() {
		cancelPour()
		wg.Wait() // this goes back down

		SetXarmSpeedLog(ctx, vc.c.BottleArm, 50, 50, vc.logger)

		err := vc.doAll(ctx, "pour", "finish", 50)
		if err != nil {
			vc.logger.Infof("error in pour cleanup: %v", err)
		}
	}()

	// create directory where we save images, named after start time
	pourTime := time.Now().Format("20060102_150405.000")
	subDir := filepath.Join(trainingDataDirName, pourTime)
	if err := os.Mkdir(subDir, 0o755); err != nil {
		return err
	}
	vc.imgDirName = subDir

	if vc.useMLModel {
		vc.logger.Info("*** using ml pour model ***")
	} else {
		vc.logger.Info("*** using image delta logic ***")
	}

	start := time.Now()
	vc.logger.Infow("Got start timestamp for pour loop", "startTime", start.String())
	loopNumber := 0

	for time.Since(start) < totalTime {
		loopStart := time.Now()

		img, fn, err := vc.GetGlassPourCamImage(ctx, box, loopNumber)
		if err != nil {
			return err
		}

		if vc.useMLModel {
			isFull, err := vc.handleMLPour(ctx, img, loopNumber)
			if err != nil {
				return err
			}
			if isFull {
				break
			}
		} else {
			if pd == nil {
				pd = newPourDetector(img)
			} else {
				delta, _ := pd.differentDebug(img)
				deltaMax := vc.conf.glassPourMotionThreshold()
				vc.logger.Infof("fn: %v delta: %0.2f (%f)", fn, delta, deltaMax)
				if delta >= deltaMax && !markedDifferent {
					vc.logger.Infof(" **** motion detected *** ")
					markedDifferent = true
					totalTime = time.Since(start) + time.Second
				}
			}
		}

		sleepTime := (100 * time.Millisecond) - time.Since(loopStart)
		vc.logger.Infof("going to sleep for %v", sleepTime)
		time.Sleep(sleepTime)
		loopNumber++
	}

	// cleanup done in defer above
	vc.logger.Infow(" **** pour loop done **** ", "elapsed time", time.Since(start).String())
	return nil
}

func (vc *VinoCart) handleMLPour(ctx context.Context, img image.Image, loopNumber int) (bool, error) {
	label, score, err := vc.getPourDetails(ctx, img)
	if err != nil {
		return false, err
	}

	compositeLogStr := fmt.Sprintf("loopNumber: %d, label: %s, score: %0.2f", loopNumber, label, score)

	if label == "full" {
		vc.logger.Infow(" **** should stop pour *** ", "loopInfo", compositeLogStr)
		return true, nil
	}
	vc.logger.Infow(" **** should not stop pour *** ", "loopInfo", compositeLogStr)
	return false, nil
}

func (vc *VinoCart) CancelPour() error {
	if vc.cancelPour == nil {
		return fmt.Errorf("no pour in progress")
	}

	vc.logger.Info("CancelPour called - canceling pour")
	vc.cancelPour()
	return nil
}

func saveImage(img image.Image, dirName string, loopNumber int, logger logging.Logger) (string, error) {
	fn := fmt.Sprintf("%s/img-%02d.png", dirName, loopNumber)

	file, err := os.Create(fn)
	if err != nil {
		return fn, fmt.Errorf("couldn't create filename %w", err)
	}
	logger.Infof("saving image %s", fn)
	defer file.Close()
	return fn, png.Encode(file, img)
}

func (vc *VinoCart) PutBack(ctx context.Context) error {
	vc.setStatus("placing")
	err := vc.doAll(ctx, "put-back", "before-open", 50)
	if err != nil {
		return err
	}

	err = vc.moveToCurrentXYAtCupHeight(ctx)
	if err != nil {
		return err
	}

	err = vc.c.BottleGripper.Open(ctx, nil)
	if err != nil {
		return err
	}

	err = vc.c.Gripper.Open(ctx, nil)
	if err != nil {
		return err
	}

	time.Sleep(time.Millisecond * 500)

	return vc.doAll(ctx, "put-back", "post-open", 100)
}

func (vc *VinoCart) PourMotionDemo(ctx context.Context, pp *PourPositions) error {
	err := SetXarmSpeed(ctx, vc.c.BottleArm, 75, 75)
	if err != nil {
		return err
	}

	err = vc.doAll(ctx, "pour", "prep", 75)
	if err != nil {
		return err
	}

	pourContext, cancel := context.WithCancel(ctx)
	wg := sync.WaitGroup{}
	wg.Add(1)

	go func() {
		defer wg.Done()
		err := vc.doPourMotion(ctx, pourContext, pp)
		if err != nil {
			vc.logger.Infof("eliot: %v", err)
		}
	}()

	time.Sleep(2 * time.Second)

	vc.logger.Infof("cancel called")
	cancel()

	wg.Wait()
	vc.logger.Infof("wait done")

	return nil
}

func (vc *VinoCart) doPourMotion(ctx, pourContext context.Context, pp *PourPositions) error {
	err := SetXarmSpeed(ctx, vc.c.BottleArm, 20, 50)
	if err != nil {
		return err
	}
	defer SetXarmSpeedLog(ctx, vc.c.BottleArm, 50, 50, vc.logger)

	err = vc.c.BottleArm.MoveThroughJointPositions(pourContext, pp.joints, nil, nil)

	if err != nil && err != context.Canceled && pourContext.Err() != context.Canceled {
		return err
	}

	// After moving through all joint positions, we wait for the caller to signal that the pour has been completed
	select {
	case <-pourContext.Done():
	}

	vc.logger.Infof("going back down")

	cur, err := vc.c.Motion.GetPose(ctx, bottleName, "world", vc.pourExtraFrames, nil)
	if err != nil {
		return err
	}

	err = SetXarmSpeed(ctx, vc.c.BottleArm, 100, 100)
	if err != nil {
		return err
	}

	posesToDo := [][]referenceframe.Input{}

	for i := len(pp.poses) - 1; i >= 0; i-- {
		if cur.Pose().Orientation().OrientationVectorDegrees().OZ > pp.poses[i].Pose().Orientation().OrientationVectorDegrees().OZ {
			continue
		}

		posesToDo = append(posesToDo, pp.joints[i])
	}

	return vc.c.BottleArm.MoveThroughJointPositions(ctx, posesToDo, nil, nil)
}

type PourPositions struct {
	joints [][]referenceframe.Input
	poses  []*referenceframe.PoseInFrame
}

func (vc *VinoCart) SetupPourPositions(ctx context.Context) (*PourPositions, error) {
	myFs, err := touch.FrameSystemWithSomeParts(ctx, vc.c.Rfs, []string{vc.conf.BottleArm, vc.conf.BottleGripper}, vc.pourExtraFrames)
	if err != nil {
		return nil, err
	}

	startJoints, err := vc.c.BottleArm.JointPositions(ctx, nil)
	if err != nil {
		return nil, err
	}
	vc.logger.Infof("setupPourPositions startJoints (current): %v", startJoints)

	bottleTopNow, err := vc.c.Motion.GetPose(ctx, bottleName, "world", vc.pourExtraFrames, nil)
	if err != nil {
		return nil, fmt.Errorf("failed to get bottle-top pose: %w", err)
	}
	bottleStart := bottleTopNow.Pose()
	vc.logger.Infof("bottleStart (current bottle-top in world): %v", bottleStart)

	o := bottleStart.Orientation().OrientationVectorDegrees()

	joints := [][]referenceframe.Input{}
	poses := []*referenceframe.PoseInFrame{}

	pDelta := r3.Vector{}
	for o.OZ > -.5 {
		goalPose := referenceframe.NewPoseInFrame("world",
			spatialmath.NewPose(
				bottleStart.Point().Add(pDelta),
				o,
			),
		)

		vc.logger.Infof(" next: %v", goalPose.Pose())

		vc.logger.Infof("myFs %v", myFs)

		req := &armplanning.PlanRequest{
			FrameSystem: myFs,
			Goals: []*armplanning.PlanState{
				armplanning.NewPlanState(referenceframe.FrameSystemPoses{bottleName: goalPose}, nil),
			},
			StartState: armplanning.NewPlanState(nil, referenceframe.FrameSystemInputs{
				vc.conf.BottleArm: startJoints,
			}),
		}
		plan, _, err := armplanning.PlanMotion(ctx, vc.logger, req)
		if err != nil {
			return nil, fmt.Errorf("can't plan pour prep: %w", err)
		}

		for i, step := range plan.Trajectory() {
			vc.logger.Infof("[pour-tilt] plan step %d: %v", i, step[vc.conf.BottleArm])
		}
		if len(plan.Trajectory()) != 2 {
			return nil, fmt.Errorf("why is plan wrong (%d)\n %v", len(plan.Trajectory()), plan)
		}

		myJoints := plan.Trajectory()[1][vc.conf.BottleArm]
		vc.logger.Infof("joints %v", myJoints)

		if len(joints) > 0 {
			d := referenceframe.InputsL2Distance(startJoints, myJoints)
			vc.logger.Infof("\t InputsL2Distance: %v", d)
			if d > 0.15 {
				fn := "/tmp/pour-plan-bad.json"

				data, err := json.MarshalIndent(req, "", "  ")
				if err != nil {
					return nil, err
				}
				file, err := os.OpenFile(fn, os.O_CREATE|os.O_WRONLY|os.O_TRUNC, 0o600)
				if err != nil {
					return nil, err
				}
				defer file.Close()

				_, err = file.Write(data)
				if err != nil {
					return nil, err
				}

				return nil, fmt.Errorf("pourPlan pos too far %v, written to: %s", d, fn)

			}
		}

		poses = append(poses, goalPose)
		joints = append(joints, myJoints)
		startJoints = myJoints

		o.OZ -= .05
		pDelta.Z -= 1.0
		pDelta.Y -= .5
		pDelta.X += .5

	}

	if len(joints) != len(poses) {
		panic("Wtf")
	}

	return &PourPositions{joints: joints, poses: poses}, nil
}

func moveWithLinearConstraint(ctx context.Context, m motion.Service, n resource.Name, p *referenceframe.PoseInFrame, planTag string) error {
	_, err := m.Move(
		ctx,
		motion.MoveReq{
			ComponentName: n.ShortName(),
			Destination:   p,
			Constraints:   &LinearConstraint,
			Extra:         planTagExtra(planTag),
		},
	)
	return err
}

func (vc *VinoCart) FindCups(ctx context.Context) ([]*viz.Object, error) {
	objects, err := vc.c.CupFinder.GetObjectPointClouds(ctx, "", nil)
	if err != nil {
		return nil, err
	}

	return FilterObjects(objects, vc.conf.CupHeight, vc.conf.cupWidth(), 25, vc.logger), nil
}

func (vc *VinoCart) labelPour(ctx context.Context, label string) error {
	if vc.imgDirName == "" {
		vc.logger.Warn("no images to label")
		return nil
	}

	defer func() {
		if err := vc.cleanupImages(); err != nil {
			vc.logger.Errorf("failed to cleanup images: %v", err)
		}
	}()

	folderName := filepath.Base(vc.imgDirName)
	pourTime, err := time.ParseInLocation("20060102_150405.000", folderName, time.Local)
	if err != nil {
		return fmt.Errorf("could not parse folder timestamp %q: %w", folderName, err)
	}
	if age := time.Since(pourTime); age > 15*time.Minute {
		vc.logger.Infof("skipping upload of stale images (age: %v): %s", age, vc.imgDirName)
		return nil
	}

	return uploadTaggedImages(ctx, vc.c.Cam.Name().Name, vc.imgDirName, vc.dataClient, croppedCupDatasetID, label, vc.logger)
}
