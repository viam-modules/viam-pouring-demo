export interface Joint {
  index: number;
  position: number;
}
