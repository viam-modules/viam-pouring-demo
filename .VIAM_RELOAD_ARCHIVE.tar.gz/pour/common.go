package pour

import (
	"go.viam.com/rdk/resource"
)

var NamespaceFamily = resource.ModelNamespace("viam").WithFamily("pouring-demo")
